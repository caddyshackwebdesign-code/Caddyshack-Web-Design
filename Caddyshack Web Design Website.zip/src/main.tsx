import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './app/App'
import './styles/index.css'

// Check if root element exists before mounting React
// This allows the static HTML to work without JavaScript
const rootElement = document.getElementById('root');
if (rootElement && rootElement.children.length === 0) {
  // Only mount React if JavaScript is enabled AND root is empty
  document.body.classList.add('react-loaded');
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  )
}