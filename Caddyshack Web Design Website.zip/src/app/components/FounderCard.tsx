interface FounderCardProps {
  name: string;
  title: string;
  photo: string;
  gradient: string;
  imagePosition?: string;
  size?: 'small' | 'large';
}

export function FounderCard({ 
  name, 
  title, 
  photo, 
  gradient, 
  imagePosition,
  size = 'small' 
}: FounderCardProps) {
  const imageHeight = size === 'large' ? 'h-[400px]' : 'h-[300px]';
  const titleSize = size === 'large' ? 'text-2xl' : 'text-xl';
  const padding = size === 'large' ? 'p-6' : 'p-4';
  const marginBottom = size === 'large' ? 'mb-4' : 'mb-3';

  return (
    <div className={`bg-gradient-to-br ${gradient} rounded-2xl ${padding} shadow-lg`}>
      <div className={`relative ${imageHeight} rounded-xl overflow-hidden ${marginBottom} shadow-md`}>
        <img
          src={photo}
          alt={`${name} - ${title}`}
          className={`w-full h-full object-cover ${imagePosition || ''}`}
        />
      </div>
      <div className="text-center">
        <h4 className={`${titleSize} font-bold text-gray-900 mb-1`}>{name}</h4>
        <p className="text-gray-600">{title}</p>
      </div>
    </div>
  );
}