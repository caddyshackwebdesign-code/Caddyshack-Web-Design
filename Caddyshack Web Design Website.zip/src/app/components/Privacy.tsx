import { useNavigate } from 'react-router-dom';

export function Privacy() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <button 
              onClick={() => navigate('/')}
              className="flex items-center gap-2 text-gray-700 hover:text-green-600 transition-colors"
            >
              <span className="text-xl font-bold">← Back to Home</span>
            </button>
          </div>
        </nav>
      </header>

      {/* Privacy Content */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Privacy Policy</h1>
            <p className="text-xl text-gray-600">
              Effective Date: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 md:p-12 space-y-8">
            <div>
              <p className="text-gray-700">
                Caddyshack Web Design ("we," "us," or "our") values your privacy. This Privacy Policy explains how we collect, use, and protect your information when you visit our website or use our services.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Information We Collect</h2>
              <p className="text-gray-700 mb-4">
                We may collect the following types of information:
              </p>
              
              <h3 className="font-bold text-gray-900 mb-2">Personal Information</h3>
              <p className="text-gray-700 mb-2">
                When you contact us or purchase services, we may collect:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4 mb-4">
                <li>Name</li>
                <li>Email address</li>
                <li>Phone number</li>
                <li>Business name</li>
                <li>Website or domain information</li>
              </ul>
              
              <h3 className="font-bold text-gray-900 mb-2">Payment Information</h3>
              <p className="text-gray-700 mb-2">
                Payments are processed securely through Stripe.
              </p>
              <p className="text-gray-700 mb-2">
                We do not store or have access to your full credit card details.
              </p>
              <p className="text-gray-700 mb-2">
                Stripe may collect:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4 mb-2">
                <li>Billing information</li>
                <li>Payment method details</li>
                <li>Transaction data</li>
              </ul>
              <p className="text-gray-700">
                Stripe's privacy policy applies to payment processing.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">2. How We Use Your Information</h2>
              <p className="text-gray-700 mb-3">
                We use collected information to:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li>Provide and manage our services</li>
                <li>Process payments and subscriptions</li>
                <li>Communicate with you about your account or services</li>
                <li>Respond to inquiries and support requests</li>
                <li>Improve our website and services</li>
                <li>Comply with legal obligations</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">3. How We Share Information</h2>
              <p className="text-gray-700 mb-4">
                We do not sell or rent your personal information.
              </p>
              <p className="text-gray-700 mb-2">
                We may share information only with:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li>Payment processors (Stripe)</li>
                <li>Service providers required to operate our website</li>
                <li>Legal authorities, if required by law</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Cookies & Analytics</h2>
              <p className="text-gray-700 mb-2">
                Our website may use cookies or similar technologies to:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4 mb-3">
                <li>Improve site functionality</li>
                <li>Analyze website traffic</li>
                <li>Understand user behavior</li>
              </ul>
              <p className="text-gray-700">
                Third-party services such as Google Analytics may collect anonymous usage data. You can disable cookies through your browser settings.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Data Security</h2>
              <p className="text-gray-700">
                We take reasonable measures to protect your information. However, no method of transmission over the internet is 100% secure, and we cannot guarantee absolute security.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Your Rights</h2>
              <p className="text-gray-700 mb-2">
                Depending on your location, you may have the right to:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4 mb-3">
                <li>Request access to your personal data</li>
                <li>Request correction or deletion of your data</li>
                <li>Opt out of certain communications</li>
              </ul>
              <p className="text-gray-700">
                To make a request, contact us using the information below.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Third-Party Links</h2>
              <p className="text-gray-700">
                Our website may contain links to third-party websites. We are not responsible for the privacy practices or content of those sites.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Children's Privacy</h2>
              <p className="text-gray-700">
                Our services are not intended for children under the age of 13. We do not knowingly collect personal information from children.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Changes to This Policy</h2>
              <p className="text-gray-700">
                We may update this Privacy Policy from time to time. Any changes will be posted on this page with an updated effective date.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Contact Us</h2>
              <p className="text-gray-700 mb-3">
                If you have questions about this Privacy Policy, contact us at:
              </p>
              <div className="bg-gray-50 p-4 rounded-lg mt-4">
                <p className="text-gray-700"><strong>Caddyshack Web Design</strong></p>
                <p className="text-gray-700">📧 <a href="mailto:caddyshackwebdesign@gmail.com" className="text-green-600 hover:text-green-700">caddyshackwebdesign@gmail.com</a></p>
                <p className="text-gray-700">📍 St. Louis, Missouri</p>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center">
            <button 
              onClick={() => navigate('/')}
              className="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors"
            >
              Back to Home
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Caddyshack Web Design. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}