import { useNavigate, Link } from 'react-router-dom';
import { Code, Palette, Smartphone, Rocket, CircleCheck, ShoppingCart, Wrench } from 'lucide-react';
import { Header } from './Header';
import logo from 'figma:asset/f0bf4c0db30c292a9e07c4c3463e2b4d9cee8698.png';

export function ServicesPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <Header currentPage="services" />

      {/* Services Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-gray-900 mb-4">Our Services</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive web design solutions tailored to your business needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                <Code className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Custom Web Development</h2>
              <p className="text-gray-600 mb-4">
                Tailored websites built from the ground up to match your unique business requirements and brand identity.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Responsive design</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">SEO optimization</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Fast loading times</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                <Palette className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">UI/UX Design</h2>
              <p className="text-gray-600 mb-4">
                Beautiful, intuitive interfaces that provide exceptional user experiences and keep visitors engaged.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">User research</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Wireframing & prototyping</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Brand consistency</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-purple-100 rounded-lg flex items-center justify-center mb-6">
                <Smartphone className="w-8 h-8 text-purple-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Mobile Optimization</h2>
              <p className="text-gray-600 mb-4">
                Ensure your website looks perfect and functions flawlessly on all devices and screen sizes.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Mobile-first approach</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Touch-friendly interfaces</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Cross-device testing</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-orange-100 rounded-lg flex items-center justify-center mb-6">
                <Rocket className="w-8 h-8 text-orange-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Website Redesign</h2>
              <p className="text-gray-600 mb-4">
                Breathe new life into your existing website with a modern redesign that improves performance and aesthetics.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Modern design trends</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Content migration</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Performance upgrades</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-pink-100 rounded-lg flex items-center justify-center mb-6">
                <ShoppingCart className="w-8 h-8 text-pink-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">E-Commerce Solutions</h2>
              <p className="text-gray-600 mb-4">
                Build a powerful online store that drives sales with secure payment processing and inventory management.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Shopping cart integration</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Payment gateways</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Product management</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-teal-100 rounded-lg flex items-center justify-center mb-6">
                <Wrench className="w-8 h-8 text-teal-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Ongoing Support</h2>
              <p className="text-gray-600 mb-4">
                Keep your website running smoothly with regular updates, maintenance, and technical support.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Security updates</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Content updates</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Technical assistance</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Pricing Section */}
          <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl p-8 md:p-12 mb-16">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Simple, Transparent Pricing</h2>
              <p className="text-xl text-gray-600">Professional web design services at competitive rates</p>
            </div>
            <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-lg p-8">
              <div className="text-center mb-6">
                <div className="text-5xl font-bold text-gray-900 mb-2">$500</div>
                <p className="text-gray-600">One-time setup fee</p>
              </div>
              <div className="text-center mb-8">
                <div className="text-3xl font-bold text-green-600 mb-2">$100/month</div>
                <p className="text-gray-600">Ongoing maintenance and hosting</p>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <CircleCheck className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Custom website design and development</span>
                </li>
                <li className="flex items-start gap-3">
                  <CircleCheck className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Responsive design for all devices</span>
                </li>
                <li className="flex items-start gap-3">
                  <CircleCheck className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Hosting and domain management</span>
                </li>
                <li className="flex items-start gap-3">
                  <CircleCheck className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Regular updates and maintenance</span>
                </li>
                <li className="flex items-start gap-3">
                  <CircleCheck className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Technical support</span>
                </li>
              </ul>
              <p className="text-sm text-gray-500 text-center mb-6">
                * We retain ownership of the website while your subscription is active. Sites may be suspended for non-payment.
              </p>
              <div className="text-center">
                <Link
                  to="/contact"
                  className="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors inline-block"
                >
                  Get Started Today
                </Link>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to Start Your Project?</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Let's discuss your needs and create a website that helps your business grow
            </p>
            <Link
              to="/contact"
              className="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors inline-block"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <img src={logo} alt="Caddyshack Web Design Logo" className="h-12 w-auto" />
              <span className="text-xl font-bold">Caddyshack Web Design</span>
            </div>
            <p className="text-gray-400 mb-4">Creating exceptional web experiences for businesses in St. Louis and beyond.</p>
            <div className="flex gap-6 justify-center text-gray-400">
              <Link to="/" className="hover:text-green-400 transition-colors">Home</Link>
              <Link to="/about" className="hover:text-green-400 transition-colors">About</Link>
              <Link to="/services" className="hover:text-green-400 transition-colors">Services</Link>
              <Link to="/projects" className="hover:text-green-400 transition-colors">Projects</Link>
              <Link to="/contact" className="hover:text-green-400 transition-colors">Contact</Link>
              <Link to="/terms" className="hover:text-green-400 transition-colors">Terms</Link>
              <Link to="/privacy" className="hover:text-green-400 transition-colors">Privacy</Link>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 text-gray-400">
              <p>&copy; {new Date().getFullYear()} Caddyshack Web Design. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}