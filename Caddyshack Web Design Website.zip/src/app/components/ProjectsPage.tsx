import { useNavigate, Link } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Header } from './Header';
import logo from 'figma:asset/f0bf4c0db30c292a9e07c4c3463e2b4d9cee8698.png';

export function ProjectsPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <Header currentPage="projects" />

      {/* Projects Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-gray-900 mb-4">Our Demo Projects</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Check out some sample websites we've created to showcase our design capabilities
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {/* HVAC Project */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow group">
              <div className="relative h-64 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1545259742-b4fd8fea67e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aGVybW9zdGF0JTIwdGVtcGVyYXR1cmUlMjBjb250cm9sfGVufDF8fHx8MTc2NzEzNDQ3N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Caddyshack HVAC website"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-2xl font-bold text-white">Caddyshack HVAC</h3>
                </div>
              </div>
              <div className="p-6">
                <p className="text-gray-600 mb-4">
                  A comprehensive website for a heating and cooling company featuring service showcases, customer testimonials, and online booking capabilities.
                </p>
                <div className="mb-4">
                  <h4 className="font-bold text-gray-900 mb-2">Features:</h4>
                  <ul className="list-disc list-inside text-gray-600 text-sm space-y-1">
                    <li>Service area coverage map</li>
                    <li>Online appointment booking</li>
                    <li>Customer testimonials</li>
                    <li>Emergency contact features</li>
                  </ul>
                </div>
                <a
                  href="https://only-seed-88792131.figma.site"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 font-medium group/link"
                >
                  View Website
                  <ExternalLink className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>

            {/* Landscaping Project */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow group">
              <div className="relative h-64 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1748893790747-fc2646924cbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXduJTIwbW93ZXIlMjBncmFzcyUyMGN1dHRpbmd8ZW58MXx8fHwxNzY3MTM0NDc2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Caddyshack Landscaping website"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-2xl font-bold text-white">Caddyshack Landscaping</h3>
                </div>
              </div>
              <div className="p-6">
                <p className="text-gray-600 mb-4">
                  A beautiful portfolio website for a landscaping business with project galleries, service packages, and seasonal maintenance plans.
                </p>
                <div className="mb-4">
                  <h4 className="font-bold text-gray-900 mb-2">Features:</h4>
                  <ul className="list-disc list-inside text-gray-600 text-sm space-y-1">
                    <li>Before/after photo galleries</li>
                    <li>Service package pricing</li>
                    <li>Seasonal maintenance schedules</li>
                    <li>Quote request form</li>
                  </ul>
                </div>
                <a
                  href="https://mining-erase-38632402.figma.site"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 font-medium group/link"
                >
                  View Website
                  <ExternalLink className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>

            {/* Cleaning Services Project */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow group">
              <div className="relative h-64 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1763026227930-ec2c91d4e7f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGVhbmluZyUyMGdsb3ZlcyUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NjcxMzQ0Nzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Caddyshack Cleaning Services website"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-2xl font-bold text-white">Caddyshack Cleaning</h3>
                </div>
              </div>
              <div className="p-6">
                <p className="text-gray-600 mb-4">
                  A professional website for a cleaning company with instant quotes, online scheduling, and service area coverage maps.
                </p>
                <div className="mb-4">
                  <h4 className="font-bold text-gray-900 mb-2">Features:</h4>
                  <ul className="list-disc list-inside text-gray-600 text-sm space-y-1">
                    <li>Instant online quotes</li>
                    <li>Online booking system</li>
                    <li>Service area maps</li>
                    <li>Customer reviews section</li>
                  </ul>
                </div>
                <a
                  href="https://stunt-fixed-68256756.figma.site"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 font-medium group/link"
                >
                  View Website
                  <ExternalLink className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          </div>

          {/* Info Section */}
          <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl p-8 md:p-12 mb-16">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">These Are Just Examples</h2>
              <p className="text-lg text-gray-700 mb-6">
                These demo projects showcase the variety of designs and features we can create for different industries. Every website we build is custom-tailored to match your specific business needs, brand identity, and goals.
              </p>
              <p className="text-lg text-gray-700">
                Whether you're in HVAC, landscaping, cleaning services, or any other industry, we'll create a unique website that sets you apart from the competition.
              </p>
            </div>
          </div>

          {/* CTA Section */}
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to See Your Website Come to Life?</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Let's discuss your project and create something amazing together
            </p>
            <div className="flex gap-4 justify-center">
              <Link
                to="/contact"
                className="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors inline-block"
              >
                Start Your Project
              </Link>
              <Link
                to="/services"
                className="bg-white text-green-600 px-8 py-3 rounded-lg border-2 border-green-600 hover:bg-green-50 transition-colors inline-block"
              >
                View Services
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <img src={logo} alt="Caddyshack Web Design Logo" className="h-12 w-auto" />
              <span className="text-xl font-bold">Caddyshack Web Design</span>
            </div>
            <p className="text-gray-400 mb-4">Creating exceptional web experiences for businesses in St. Louis and beyond.</p>
            <div className="flex gap-6 justify-center text-gray-400">
              <Link to="/" className="hover:text-green-400 transition-colors">Home</Link>
              <Link to="/about" className="hover:text-green-400 transition-colors">About</Link>
              <Link to="/services" className="hover:text-green-400 transition-colors">Services</Link>
              <Link to="/projects" className="hover:text-green-400 transition-colors">Projects</Link>
              <Link to="/contact" className="hover:text-green-400 transition-colors">Contact</Link>
              <Link to="/terms" className="hover:text-green-400 transition-colors">Terms</Link>
              <Link to="/privacy" className="hover:text-green-400 transition-colors">Privacy</Link>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 text-gray-400">
              <p>&copy; {new Date().getFullYear()} Caddyshack Web Design. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}