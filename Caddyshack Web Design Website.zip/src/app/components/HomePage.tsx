import { Mail, Phone, MapPin, Code, Palette, Smartphone, Rocket, CircleCheck, Video, ExternalLink, ShoppingCart, Wrench, Instagram, Facebook } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Chatbot } from './Chatbot';
import { Header } from './Header';
import { useState, useEffect } from 'react';
import { projectId, publicAnonKey } from '../../../utils/supabase/info';
import { Link } from 'react-router-dom';
import { logo, founders } from '../constants/assets';
import { FounderCard } from './FounderCard';

export function HomePage() {
  // Google Analytics setup
  useEffect(() => {
    // Create and inject the gtag script
    const script1 = document.createElement('script');
    script1.async = true;
    script1.src = 'https://www.googletagmanager.com/gtag/js?id=G-180G8TH8SD';
    document.head.appendChild(script1);

    // Create and inject the gtag config script
    const script2 = document.createElement('script');
    script2.innerHTML = `
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'G-180G8TH8SD');
    `;
    document.head.appendChild(script2);

    return () => {
      // Cleanup on unmount
      document.head.removeChild(script1);
      document.head.removeChild(script2);
    };
  }, []);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<{ type: 'success' | 'error', message: string } | null>(null);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus(null);
    
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-b8f46a9a/contact`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify(formData),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        console.error('Failed to send message:', data);
        setSubmitStatus({
          type: 'error',
          message: 'Failed to send message. Please try again or contact us directly via email.',
        });
        return;
      }

      console.log('Message sent successfully:', data);
      setSubmitStatus({
        type: 'success',
        message: 'Thank you! Your message has been sent successfully. We\'ll get back to you soon.',
      });
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        phone: '',
        message: '',
      });
    } catch (error) {
      console.error('Error sending message:', error);
      setSubmitStatus({
        type: 'error',
        message: 'An error occurred. Please try again or contact us directly at caddyshackwebdesign@gmail.com.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <Header />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-50 to-blue-50 py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
                Web Design That Drives Results
              </h1>
              <p className="text-xl text-gray-700 mb-8">
                Based in St. Louis, Missouri, we create stunning, user-friendly websites that help your business grow and stand out online.
              </p>
              <div className="flex gap-4">
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors inline-block"
                >
                  Get Started
                </button>
                <button 
                  onClick={() => scrollToSection('services')}
                  className="bg-white text-green-600 px-8 py-3 rounded-lg border-2 border-green-600 hover:bg-green-50 transition-colors inline-block"
                >
                  Our Services
                </button>
              </div>
            </div>
            <div className="relative h-[400px] rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1603985585179-3d71c35a537c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWIlMjBkZXNpZ24lMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzY3MTA0NTIzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Web design workspace"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">About Us</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Two childhood friends from St. Louis, building exceptional web experiences together
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center mb-12">
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h3>
              <p className="text-gray-700 mb-6">
                Caddyshack Web Design was founded by Dominic Grebel and Jack Wolk, two lifelong friends who grew up as neighbors in St. Louis. What started as childhood adventures in the neighborhood has evolved into a professional partnership dedicated to creating exceptional web experiences.
              </p>
              <p className="text-gray-700 mb-6">
                Our deep-rooted friendship and shared vision allow us to work seamlessly together, combining our unique skills and perspectives to deliver websites that not only look great but also drive real business results.
              </p>
              <p className="text-gray-700 mb-8">
                We're proud to serve businesses in St. Louis and beyond, bringing the same dedication and creativity to every project that has defined our friendship for years.
              </p>
              
              <Link 
                to="/about"
                className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-block"
              >
                Learn More About Us
              </Link>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {founders.map((founder) => (
                <FounderCard 
                  key={founder.name}
                  name={founder.name}
                  title={founder.title}
                  photo={founder.photo}
                  gradient={founder.gradient}
                  imagePosition={founder.imagePosition}
                  size="small"
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive web design solutions tailored to your business needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                <Code className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Custom Web Development</h3>
              <p className="text-gray-600 mb-4">
                Tailored websites built from the ground up to match your unique business requirements and brand identity.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Responsive design</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">SEO optimization</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Fast loading times</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                <Palette className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">UI/UX Design</h3>
              <p className="text-gray-600 mb-4">
                Beautiful, intuitive interfaces that provide exceptional user experiences and keep visitors engaged.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">User research</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Wireframing & prototyping</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Brand consistency</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-purple-100 rounded-lg flex items-center justify-center mb-6">
                <Smartphone className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Mobile Optimization</h3>
              <p className="text-gray-600 mb-4">
                Ensure your website looks perfect and functions flawlessly on all devices and screen sizes.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Mobile-first approach</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Touch-friendly interfaces</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Cross-device testing</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-orange-100 rounded-lg flex items-center justify-center mb-6">
                <Rocket className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Website Redesign</h3>
              <p className="text-gray-600 mb-4">
                Breathe new life into your existing website with a modern redesign that improves performance and aesthetics.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Modern design trends</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Content migration</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Performance upgrades</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-pink-100 rounded-lg flex items-center justify-center mb-6">
                <ShoppingCart className="w-8 h-8 text-pink-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">E-Commerce Solutions</h3>
              <p className="text-gray-600 mb-4">
                Build a powerful online store that drives sales with secure payment processing and inventory management.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Shopping cart integration</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Payment gateways</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Product management</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-teal-100 rounded-lg flex items-center justify-center mb-6">
                <Wrench className="w-8 h-8 text-teal-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Ongoing Support</h3>
              <p className="text-gray-600 mb-4">
                Keep your website running smoothly with regular updates, maintenance, and technical support.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Security updates</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Content updates</span>
                </li>
                <li className="flex items-start gap-2">
                  <CircleCheck className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Technical assistance</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Demo Projects Section */}
      <section id="projects" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Demo Projects</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Check out some sample websites we've created to showcase our design capabilities
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* HVAC Project */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow group">
              <div className="relative h-64 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1545259742-b4fd8fea67e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aGVybW9zdGF0JTIwdGVtcGVyYXR1cmUlMjBjb250cm9sfGVufDF8fHx8MTc2NzEzNDQ3N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Caddyshack HVAC website"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-3">Caddyshack HVAC</h3>
                <p className="text-gray-600 mb-4">
                  A comprehensive website for a heating and cooling company featuring service showcases, customer testimonials, and online booking capabilities.
                </p>
                <a
                  href="https://only-seed-88792131.figma.site"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 font-medium group/link"
                >
                  View Website
                  <ExternalLink className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>

            {/* Landscaping Project */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow group">
              <div className="relative h-64 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1748893790747-fc2646924cbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXduJTIwbW93ZXIlMjBncmFzcyUyMGN1dHRpbmd8ZW58MXx8fHwxNzY3MTM0NDc2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Caddyshack Landscaping website"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-3">Caddyshack Landscaping</h3>
                <p className="text-gray-600 mb-4">
                  A beautiful portfolio website for a landscaping business with project galleries, service packages, and seasonal maintenance plans.
                </p>
                <a
                  href="https://mining-erase-38632402.figma.site"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 font-medium group/link"
                >
                  View Website
                  <ExternalLink className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>

            {/* Cleaning Services Project */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow group">
              <div className="relative h-64 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1763026227930-ec2c91d4e7f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGVhbmluZyUyMGdsb3ZlcyUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NjcxMzQ0Nzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Caddyshack Cleaning Services website"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-3">Caddyshack Cleaning Services</h3>
                <p className="text-gray-600 mb-4">
                  A professional website for a cleaning company with instant quotes, online scheduling, and service area coverage maps.
                </p>
                <a
                  href="https://stunt-fixed-68256756.figma.site"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-green-600 hover:text-green-700 font-medium group/link"
                >
                  View Website
                  <ExternalLink className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-600 mb-6">
              These demo projects showcase the variety of designs and features we can create for different industries. Want to see what we can do for your business?
            </p>
            <button
              onClick={() => scrollToSection('contact')}
              className="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors inline-block"
            >
              Start Your Project
            </button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Get In Touch</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Contact Information</h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Email</h4>
                    <a href="mailto:caddyshackwebdesign@gmail.com" className="text-gray-700 hover:text-green-600">
                      caddyshackwebdesign@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Phone</h4>
                    <a href="tel:314-532-9766" className="text-gray-700 hover:text-blue-600">
                      314-532-9766
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Video className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Communication Options</h4>
                    <p className="text-gray-700">
                      We're available via phone call or Zoom for your convenience
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Location</h4>
                    <p className="text-gray-700">St. Louis, Missouri</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Instagram className="w-6 h-6 text-pink-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Follow Us</h4>
                    <a 
                      href="https://www.instagram.com/caddyshackwebdesign" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-gray-700 hover:text-pink-600 transition-colors"
                    >
                      @caddyshackwebdesign
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Facebook className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">Follow Us</h4>
                    <a 
                      href="https://www.facebook.com/caddyshackwebdesign" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-gray-700 hover:text-blue-600 transition-colors"
                    >
                      @caddyshackwebdesign
                    </a>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-6 bg-green-50 rounded-xl">
                <h4 className="font-bold text-gray-900 mb-2">Why Choose Us?</h4>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CircleCheck className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Local St. Louis business</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CircleCheck className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Personalized service</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CircleCheck className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Competitive pricing</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CircleCheck className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Flexible communication</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="bg-gray-50 p-8 rounded-xl">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Send Us a Message</h3>
              
              {submitStatus && (
                <div className={`mb-6 p-4 rounded-lg ${
                  submitStatus.type === 'success' 
                    ? 'bg-green-100 text-green-800 border border-green-200' 
                    : 'bg-red-100 text-red-800 border border-red-200'
                }`}>
                  {submitStatus.message}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block font-medium text-gray-900 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    disabled={isSubmitting}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed"
                    placeholder="Your name"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block font-medium text-gray-900 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    disabled={isSubmitting}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed"
                    placeholder="your.email@example.com"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block font-medium text-gray-900 mb-2">
                    Phone (optional)
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    disabled={isSubmitting}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed"
                    placeholder="(123) 456-7890"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block font-medium text-gray-900 mb-2">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows={5}
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    disabled={isSubmitting}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent outline-none resize-none disabled:bg-gray-100 disabled:cursor-not-allowed"
                    placeholder="Tell us about your project..."
                  ></textarea>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? 'Sending...' : 'Send Message'}
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <img src={logo} alt="Caddyshack Web Design Logo" className="h-12 w-auto" />
                <span className="text-xl font-bold">Caddyshack Web Design</span>
              </div>
              <p className="text-gray-400">
                Creating exceptional web experiences for businesses in St. Louis and beyond.
              </p>
            </div>

            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <Link to="/about" className="text-gray-400 hover:text-green-400 transition-colors">About Us</Link>
                </li>
                <li>
                  <Link to="/services" className="text-gray-400 hover:text-green-400 transition-colors">Services</Link>
                </li>
                <li>
                  <Link to="/projects" className="text-gray-400 hover:text-green-400 transition-colors">Projects</Link>
                </li>
                <li>
                  <Link to="/terms" className="text-gray-400 hover:text-green-400 transition-colors">Terms of Service</Link>
                </li>
                <li>
                  <Link to="/privacy" className="text-gray-400 hover:text-green-400 transition-colors">Privacy Policy</Link>
                </li>
                <li>
                  <Link to="/contact" className="text-gray-400 hover:text-green-400 transition-colors">Contact</Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>St. Louis, Missouri</li>
                <li>
                  <a href="mailto:caddyshackwebdesign@gmail.com" className="hover:text-green-400 transition-colors">
                    caddyshackwebdesign@gmail.com
                  </a>
                </li>
                <li>
                  <a href="tel:314-532-9766" className="hover:text-green-400 transition-colors">
                    314-532-9766
                  </a>
                </li>
                <li>
                  <a 
                    href="https://www.instagram.com/caddyshackwebdesign" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:text-pink-400 transition-colors inline-flex items-center gap-2"
                  >
                    <Instagram className="w-4 h-4" />
                    @caddyshackwebdesign
                  </a>
                </li>
                <li>
                  <a 
                    href="https://www.facebook.com/caddyshackwebdesign" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:text-blue-400 transition-colors inline-flex items-center gap-2"
                  >
                    <Facebook className="w-4 h-4" />
                    @caddyshackwebdesign
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Caddyshack Web Design. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Chatbot */}
      <Chatbot />
    </div>
  );
}