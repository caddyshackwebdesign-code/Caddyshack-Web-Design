import { useNavigate } from 'react-router-dom';

export function Terms() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <button 
              onClick={() => navigate('/')}
              className="flex items-center gap-2 text-gray-700 hover:text-green-600 transition-colors"
            >
              <span className="text-xl font-bold">← Back to Home</span>
            </button>
          </div>
        </nav>
      </header>

      {/* Terms Content */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Terms and Conditions</h1>
            <p className="text-xl text-gray-600">
              Please read these terms carefully before using our services
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 md:p-12 space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Service Overview</h2>
              <p className="text-gray-700 mb-3">
                Caddyshack Web Design ("we," "us," or "our") provides professional website design, development, hosting, and ongoing maintenance services to clients ("you" or "your"). Our services include:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li>A one-time website design and setup fee of $500</li>
                <li>A recurring monthly subscription fee of $100 for hosting, maintenance, and ongoing support</li>
              </ul>
              <p className="text-gray-700 mt-3">
                By purchasing our services, you agree to these Terms and Conditions.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Website Ownership & Licensing</h2>
              
              <h3 className="font-bold text-gray-900 mb-2">Ownership:</h3>
              <p className="text-gray-700 mb-4">
                Caddyshack Web Design retains ownership of all websites, source code, designs, and related digital assets created for clients while the monthly subscription remains active and in good standing.
              </p>
              
              <h3 className="font-bold text-gray-900 mb-2">License to Use:</h3>
              <p className="text-gray-700 mb-4">
                You are granted a limited, non-transferable license to use the website for your business purposes during the active subscription period.
              </p>
              
              <h3 className="font-bold text-gray-900 mb-2">Upon Cancellation:</h3>
              <p className="text-gray-700 mb-2">
                If your subscription is canceled or terminated:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4 mb-4">
                <li>Your website will be taken offline</li>
                <li>The license to use the website ends</li>
                <li>We are not obligated to provide copies of source code, design files, or website assets</li>
              </ul>
              
              <h3 className="font-bold text-gray-900 mb-2">Optional Buyout:</h3>
              <p className="text-gray-700">
                At our discretion, clients may request to purchase full ownership rights at fair market value. Approval and pricing are not guaranteed.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Monthly Subscription Requirement</h2>
              <p className="text-gray-700 mb-3">
                An active monthly subscription is required to keep your website live. The $100/month subscription includes:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li>Website hosting and server maintenance</li>
                <li>Security updates and monitoring</li>
                <li>Regular backups</li>
                <li>Technical support</li>
                <li>Performance monitoring</li>
                <li>Minor content updates (reasonable use)</li>
              </ul>
            </div>

            <div className="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Non-Payment & Service Suspension</h2>
              <p className="text-gray-700 mb-3">
                Failure to maintain an active subscription may result in service interruption.
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4 mb-4">
                <li><strong>Automatic Billing:</strong> Payments are billed automatically each month</li>
                <li><strong>Failed Payments:</strong> If payment fails, Stripe will attempt multiple retries</li>
                <li><strong>Grace Period:</strong> If payment is not resolved within 7 days, your website may be temporarily suspended</li>
                <li><strong>Suspension:</strong> Suspended sites may display a "Service Temporarily Unavailable" message</li>
                <li><strong>Extended Non-Payment:</strong> Accounts inactive for 30 days or more may be permanently removed, including all backups</li>
              </ul>
              
              <h3 className="font-bold text-gray-900 mb-2">Reactivation Fee:</h3>
              <p className="text-gray-700 mb-3">
                A $50 reactivation fee may apply to restore suspended services.
              </p>
              
              <h3 className="font-bold text-gray-900 mb-2">No Refunds:</h3>
              <p className="text-gray-700">
                All payments are non-refundable, including the initial setup fee and monthly subscription fees.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Payment Terms</h2>
              <p className="text-gray-700 mb-3">
                By subscribing, you agree to:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4 mb-3">
                <li>Automatic recurring billing via Stripe</li>
                <li>Maintaining a valid payment method on file</li>
                <li>Paying all applicable taxes and transaction fees</li>
                <li>Responsibility for all charges incurred under your account</li>
              </ul>
              <p className="text-gray-700">
                All charges are due immediately upon billing.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Cancellation Policy</h2>
              <p className="text-gray-700 mb-3">
                You may cancel your subscription at any time by providing written notice via email to:
              </p>
              <p className="text-gray-700 mb-3">
                📧 <a href="mailto:caddyshackwebdesign@gmail.com" className="text-green-600 hover:text-green-700">caddyshackwebdesign@gmail.com</a>
              </p>
              <p className="text-gray-700 mb-2">
                Upon cancellation:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li>Your website will remain live through the end of the current paid billing period</li>
                <li>After the billing period ends, your website will be taken offline</li>
                <li>The $500 setup fee is non-refundable</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Service Modifications</h2>
              <p className="text-gray-700">
                We reserve the right to modify pricing, services, or these Terms at any time. Continued use of our services after changes are posted constitutes acceptance of the updated Terms.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Limitation of Liability</h2>
              <p className="text-gray-700">
                Caddyshack Web Design shall not be liable for any indirect, incidental, special, or consequential damages, including but not limited to loss of revenue, business interruption, or data loss arising from the use or inability to use our services.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Client Responsibilities</h2>
              <p className="text-gray-700 mb-3">
                You agree to:
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                <li>Provide accurate and timely content and information</li>
                <li>Ensure all content complies with applicable laws</li>
                <li>Maintain valid billing information</li>
                <li>Not use the website for unlawful or infringing activities</li>
                <li>Promptly notify us of any suspected security issues</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Contact Information</h2>
              <p className="text-gray-700 mb-3">
                For questions regarding these Terms, contact:
              </p>
              <div className="bg-gray-50 p-4 rounded-lg mt-4">
                <p className="text-gray-700"><strong>Caddyshack Web Design</strong></p>
                <p className="text-gray-700">📧 <a href="mailto:caddyshackwebdesign@gmail.com" className="text-green-600 hover:text-green-700">caddyshackwebdesign@gmail.com</a></p>
                <p className="text-gray-700">📍 St. Louis, Missouri</p>
              </div>
            </div>

            <div className="border-t pt-6">
              <p className="text-sm text-gray-600 italic">
                Last Updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
              <p className="text-sm text-gray-600 mt-4">
                By using our services, you acknowledge that you have read, understood, and agree to be bound by these Terms and Conditions.
              </p>
            </div>
          </div>

          <div className="mt-8 text-center">
            <button 
              onClick={() => navigate('/')}
              className="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors"
            >
              Back to Home
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Caddyshack Web Design. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}