import { Header } from './Header';
import { Chatbot } from './Chatbot';
import { founders, logo } from '../constants/assets';
import { FounderCard } from './FounderCard';
import { Link } from 'react-router-dom';
import { Instagram, Facebook, CircleCheck } from 'lucide-react';

export function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <Header currentPage="about" />

      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-gray-900 mb-4">About Us</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Two childhood friends from St. Louis, building exceptional web experiences together
            </p>
          </div>
          
          {/* Our Story Section */}
          <div className="mb-16 max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
            <p className="text-gray-700 mb-6">
              Caddyshack Web Design was founded by Dominic Grebel and Jack Wolk, two lifelong friends who grew up as neighbors in St. Louis. What started as childhood adventures in the neighborhood has evolved into a professional partnership dedicated to creating exceptional web experiences.
            </p>
            <p className="text-gray-700 mb-6">
              Our deep-rooted friendship and shared vision allow us to work seamlessly together, combining our unique skills and perspectives to deliver websites that not only look great but also drive real business results.
            </p>
            <p className="text-gray-700">
              We're proud to serve businesses in St. Louis and beyond, bringing the same dedication and creativity to every project that has defined our friendship for years.
            </p>
          </div>

          {/* Team Photos Section */}
          <div className="grid md:grid-cols-2 gap-8 mb-16 max-w-5xl mx-auto">
            {founders.map((founder) => (
              <FounderCard 
                key={founder.name}
                name={founder.name}
                title={founder.title}
                photo={founder.photo}
                gradient={founder.gradient}
                imagePosition={founder.imagePosition}
                size="large"
              />
            ))}
          </div>

          {/* Why Choose Us */}
          <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl p-8 md:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Why Choose Caddyshack Web Design?</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <CircleCheck className="w-10 h-10 text-green-600 mb-4" />
                <h3 className="font-bold text-gray-900 mb-2">Local St. Louis Business</h3>
                <p className="text-gray-600">We understand the local market and community needs</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <CircleCheck className="w-10 h-10 text-blue-600 mb-4" />
                <h3 className="font-bold text-gray-900 mb-2">Personalized Service</h3>
                <p className="text-gray-600">Direct communication with the co-founders on every project</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <CircleCheck className="w-10 h-10 text-purple-600 mb-4" />
                <h3 className="font-bold text-gray-900 mb-2">Competitive Pricing</h3>
                <p className="text-gray-600">Quality web design that fits your budget</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <CircleCheck className="w-10 h-10 text-orange-600 mb-4" />
                <h3 className="font-bold text-gray-900 mb-2">Flexible Communication</h3>
                <p className="text-gray-600">Available via phone, email, or Zoom for your convenience</p>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-16 text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to Work Together?</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Let's discuss your project and see how we can help bring your vision to life
            </p>
            <div className="flex gap-4 justify-center">
              <Link
                to="/contact"
                className="bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors inline-block"
              >
                Get In Touch
              </Link>
              <Link
                to="/services"
                className="bg-white text-green-600 px-8 py-3 rounded-lg border-2 border-green-600 hover:bg-green-50 transition-colors inline-block"
              >
                View Services
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <img src={logo} alt="Caddyshack Web Design Logo" className="h-12 w-auto" />
              <span className="text-xl font-bold">Caddyshack Web Design</span>
            </div>
            <p className="text-gray-400 mb-4">Creating exceptional web experiences for businesses in St. Louis and beyond.</p>
            <div className="flex gap-6 justify-center text-gray-400">
              <Link to="/" className="hover:text-green-400 transition-colors">Home</Link>
              <Link to="/about" className="hover:text-green-400 transition-colors">About</Link>
              <Link to="/services" className="hover:text-green-400 transition-colors">Services</Link>
              <Link to="/projects" className="hover:text-green-400 transition-colors">Projects</Link>
              <Link to="/contact" className="hover:text-green-400 transition-colors">Contact</Link>
              <Link to="/terms" className="hover:text-green-400 transition-colors">Terms</Link>
              <Link to="/privacy" className="hover:text-green-400 transition-colors">Privacy</Link>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 text-gray-400">
              <p>&copy; {new Date().getFullYear()} Caddyshack Web Design. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}