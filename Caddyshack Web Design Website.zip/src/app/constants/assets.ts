// Centralized asset imports
import dominicPhoto from 'figma:asset/0746d7777ce80dca5f91c16b731689c4a49837a6.png';
import jackPhoto from 'figma:asset/eae36094fc33d11752d15c836c0fb1762de85ce0.png';
import logo from 'figma:asset/f0bf4c0db30c292a9e07c4c3463e2b4d9cee8698.png';

export { dominicPhoto, jackPhoto, logo };

// Founder data
export const founders = [
  {
    name: 'Dominic Grebel',
    title: 'Co-Founder',
    photo: dominicPhoto,
    gradient: 'from-green-50 to-green-100',
  },
  {
    name: 'Jack Wolk',
    title: 'Co-Founder',
    photo: jackPhoto,
    gradient: 'from-blue-50 to-blue-100',
    imagePosition: 'object-top' as const,
  },
];
